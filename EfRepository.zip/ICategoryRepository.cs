﻿using BusinessLayer;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace DataLayer
{
    public interface ICategoryRepository : IRepository<Category>
    {
        bool UniqueCategory(string name, int? id);
        Category GetBy(string categoryName);
        Category GetBy(int id);
    }
}