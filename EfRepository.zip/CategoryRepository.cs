﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data.Entity;
using BusinessLayer;

namespace DataLayer
{
    public class CategoryRepository :EfRepository<Category>,ICategoryRepository
    {
        public CategoryRepository(DbContext context, bool sharedContext)
            : base(context, sharedContext)  {}

        public bool UniqueCategory(string name, int? id)
        {
            var category = Find(c => c.Name == name && c.Id != id);

            if(category != null)
            {
                return true;
            }

            return false;
        }


        public Category GetBy(string categoryName)
        {
            return Find(c => c.Name == categoryName);
        }

        public Category GetBy(int id)
        {
            return Find(id);
        }
    }
}